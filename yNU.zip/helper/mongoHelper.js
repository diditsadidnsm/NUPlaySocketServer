const mongoose = require('mongoose');

exports.getOneData = (collection, filter) => {
    return new Promise((resolve, reject) => {
        
    });
}